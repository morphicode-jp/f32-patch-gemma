# Supplementary Materials — Gemma 4 31B F32 Patch (paper v5)

Raw experimental data referenced in the paper for direct verification of statistical claims.

## Contents

| File | Description | Cited in paper |
|---|---|---|
| `exp162_summary.json` | Paper v1 reference: 4-bench full evaluation at Q1 / Q2 / Q4 with L25+L26 ×1.5 patch | §3 main results table |
| `exp166_runs.jsonl` | n=32 × 4 patches × 4 prompts = 512 runs, complete trace logs with timing, token counts, and behavioral coding (mid_wait, tail_reflex, aux_spontaneous, compute_correct) | §5.4 (L26-alone aux 56% vs L25-alone 16%, Fisher p<0.01) |
| `exp167_summary.json`, `exp167_bench.jsonl` | L25-alone and L26-alone single-layer full-benchmark (HS/WG/GSM/ARC) | §5.4 single-layer ablation |
| `exp168_summary.json`, `exp168_bench.jsonl` | Triple patch (LOS27+PAN17+PAN43 ×1.8) full-benchmark, avg +9.65pt benchmark gain | §5.5 Goodhart's Law instance |
| `exp169_summary.json`, `exp169_triple_runs.jsonl` | Triple patch n=32 coin recurrence under T=0.7 interactive conditions: 12.5% correct vs 93.75% for paper v1 mix (Fisher exact p=1.11e-11) | §5.5 (silent_slip rate 89.3%, doubt loop pathology) |

## Reproduction protocol

All measurements via:
- llama.cpp build `llama-b9016-cuda13.1` (Windows binary, `llama-perplexity.exe` for HS/WG/ARC, `llama-cli.exe` for GSM8k generation)
- HellaSwag: `--hellaswag --hellaswag-tasks 10042 -c 1024 -fa on`
- GSM8k: `-c 16384 -n 8192 --temp 0.0 --cache-type-k q8_0 --cache-type-v q8_0 -fa on` (paper-grade ctx)
- Winogrande: `--winogrande --winogrande-tasks 1267 -c 512 -fa on`
- ARC-C: `--hellaswag --hellaswag-tasks 1165 -c 1024 -fa on` (arc-challenge-format converted)
- Hardware: single RTX 5090 (32 GB VRAM), Windows 11 Pro

## Statistical claims

The McNemar p=0.0007 paper-grade GSM result (§5.3, n=500 paired) used per-problem pairing
between baseline Q2_K and patched L25+L26 ×1.5 Q2_K. Per-problem records are not included
in this initial supplementary bundle; they will be released with the v5.1 update along with
a unified JSONL format covering all 4 benchmarks across all 3 release quantizations.

## License

CC-BY-4.0 for these data files. Apache 2.0 for the code that generated them
(see GitHub repository).
